
public class Labyrnth
{
    public String getGreeting()
    {
        return "You have now entered the Labyrnth. \n"
        +"Your goal is to exit. \n"
        +"You will play this game of chance by entering what direction you would like to go. \n"
        +"If you ever want to exit the labyrnth just say 'get me out of here' or 'exit'. \n"
        +"To being type 'lets go' \n";

    }

    public String getResponse(String statement)
    {
        String response = "";

        if (statement.indexOf("lets go")>= 0
        || statement.indexOf("let's go") >= 0
        || statement.indexOf("Lets go") >= 0
        || statement.indexOf("Let's go") >= 0)
        { 
            response = "Your walking down rocky tunnnel, \n"
            +"moss growing out of controll along the walls, \n"
            +"when you see a small torch at the end of the trail. \n"
            +"You run just a bit faster when you hear drips behind you. \n" 
            +"When you reach the end you see you can either go left or right. \n" 
            +"What will you choose? \n";
        }

        else if (statement.indexOf("left") >= 0)
        {
            String responseL = getRandomLeft();;
            return responseL;
        }

        else if (statement.indexOf("right") >= 0)
        {
            String responseR = getRandomRight();;
            return responseR;
        }

        else if (statement.indexOf("strait") >= 0)
        {
            String responseS = getRandomStraight();;
            return responseS;
        }

        else if (statement.indexOf("back") >= 0)
        {
            String responseB = getRandomBack();;
            return responseB;
        }

        return response;
    }

    private String getRandomLeft()
    {
        final int NUMBER_OF_RESPONSES = 6;
        double r = Math.random();
        int whichResponseL = (int)(r * NUMBER_OF_RESPONSES);
        String responseL = "";

        if (whichResponseL == 0)
        {
            System.out.println("You can say 'lets go' to play \n"
                +"again or say 'exit' to stop \n");
            responseL = "You spin to the left and run as fast as possible. \n"
            +"But you hit a dead end. \n"
            +"You hear the drips behind you getting closer and louder. \n" 
            +"You freeze in fear. And that was the last of you. \n"
            +"You stand there frozen till this day. #freezeframe \n";
        }
        else if (whichResponseL == 1)
        {
            responseL = "As you run you trip over a big boulder \n"
            +"in the middle of the tunnel. \n"
            +"Your leg starts gushing blood. \n"
            +"You see just up ahead a tunnel to the right. \n"
            +"Do you continue strait into the darkness or turn right? \n";
        }
        else if (whichResponseL == 2)
        {
            responseL = "You approach a big room. \n"
            +"This room had a huge tree half dead. \n"
            +"Behind this tree is 3 doorways. \n"
            +"Would you like to continue in the left right or strait door? \n";
        }
        else if (whichResponseL == 3)
        {
            responseL = "You spin around left and run and run for so long! \n"
            +"The tunnel is pitch black. \n"
            +"You can continue strait into the darkness\n"
            +" or go back to find another route \n";
        }
        else if (whichResponseL == 4)
        {
            responseL = "You dash around the left corner \n"
            +"and a ways down the tunnel \n"
            +"you see another torch. \n"
            +"Once you run upon this tourch you can turn either \n"
            +"back or to the left or the right. Which do you go? \n";
        }
        else if (whichResponseL == 5)
        {
            responseL = "Congradulations!\n"
            +" Weather this was a long or short trip for you!\n"
            +" YOU MADE IT OUT!";
        }

        return responseL;
    }

    private String getRandomRight()
    {
        final int NUMBER_OF_RESPONSES = 6;
        double r = Math.random();
        int whichResponseR = (int)(r * NUMBER_OF_RESPONSES);
        String responseR = "";

        if (whichResponseR == 0)
        {
            System.out.println("You can say 'lets go' to play \n"
                +"again or say 'exit' to stop \n");
            responseR = " You turn right to see a \n"
            +"small red light down a few yards\n"
            +" you jog down to the light. \n"
            +"You realize its a dead end. There was some\n"
            +" small writing under the light. It said 'This is your end' \n"
            +"Then boom a door closed behind you and you were stuck. \n"
            +"You starve to death. #redlightmeansstop ";
        }
        else if (whichResponseR == 1)
        {
            responseR = "You run around the right corner to see\n"
            +" a big monster called the minotaur. \n"
            +"Do you run back or try to pass him and go to the left tunnel? \n";
        }
        else if (whichResponseR == 2)
        {
            responseR = "Whoof you barely survived that one\n"
            +" you almost got the minotaur choice :) \n"
            +"now that were continuing would you like to go back or\n"
            +" take the left just ahead? \n";
        }
        else if (whichResponseR == 3)
        {
            responseR = "You run to the right in such a panic\n"
            +" you dont realize there is a huge pipe hanging out of the wall\n"
            +" and it jabs you side. You continue running and your side is bleeding now.\n"
            +" You see a small tourch just ahead and you find you can go right or strait.\n"
            +" Which do you choose? \n";
        }
        else if (whichResponseR == 4)
        {
            responseR = "After turning right you see a broken flashlight\n"
            +" thats flickering and you hear rustling down the way.\n"
            +" Do you continue strait or turn back? \n";
        }
        else if (whichResponseR == 5)
        {
            responseR = "Congradulations!\n"
            +" Weather this was a long or short trip for you!\n"
            +" YOU MADE IT OUT! \n";
        }

        return responseR;
    }

    private String getRandomStraight()
    {
        final int NUMBER_OF_RESPONSES = 6;
        double r = Math.random();
        int whichResponseS = (int)(r * NUMBER_OF_RESPONSES);
        String responseS = "";

        if (whichResponseS == 0)
        {
            System.out.println("You can say 'lets go' to play\n"
                +" again or say 'exit' to stop \n");
            responseS = " You run strait to realize the walls\n"
            +" of the labyrnth are changing. \n"
            +"They are now made of brick.\n"
            +" You can hear th walls shake as you run.\n"
            +" You trip and fall hitting your head.\n"
            +" When you spin around to lay on your back \n"
            +"you see a brick fall down strait on your face. \n"
            +"#Deathbybricktotheface \n";
        }
        else if (whichResponseS == 1)
        {
            responseS = " You continue on strait and see the walls of the tunnel\n"
            +" gradually get taller. \n"
            +"You hear faint squueks above you. \n"
            +"You realize the roof is covered with bats.\n"
            +" You quietly proceed so you dont wake them up.\n"
            +" When you hit the end you can either go strait or left.\n"
            +" Which do you choose? \n";
        }
        else if (whichResponseS == 2)
        {
            responseS = " You run strait and when you look back\n"
            +" you see a giant human like rat coming up behind you.\n"
            +" You run even faster. You see you can run left or right.\n"
            +" Where do you go? \n";
        }
        else if (whichResponseS == 3)
        {
            responseS = "When you continue strait the tunnel start\n"
            +" too feel a bit cooler. \n"
            +"You hear the sound of water up ahead.\n"
            +" theres a small ditch you take a drink to revive\n"
            +" yourself from all the running. past the ditch\n"
            +" you can either go back or right or left where do you go? \n";
        }
        else if (whichResponseS == 4)
        {
            responseS = "You continue strait for a short distance\n"
            +" before you hear a few screams up ahead. \n"
            +"Scary part is it wasnt from anything human. \n"
            +"You can turn left where you heard the screams or just run back. \n";
        }
        else if (whichResponseS == 5)
        {
            responseS = "Congradulations! \n"
            +"Weather this was a long or short trip for you! \n"
            +"YOU MADE IT OUT! \n";
        }

        return responseS;
    }

    private String getRandomBack()
    {
        final int NUMBER_OF_RESPONSES = 6;
        double r = Math.random();
        int whichResponseB = (int)(r * NUMBER_OF_RESPONSES);
        String responseB = "";
        String response = "";

        if (whichResponseB == 0)
        {
            responseB = " You run back still terrified of what\n"
            +" those drips could have been. You are walking back when a\n"
            +" centipead runs over your foot. You let our a scream. \n"
            +"But unfortunately your scream raddled the walls \n"
            +"and they collapse right on you. \n"
            +"#dogpile \n";
            System.out.println("You can say 'lets go' to play\n"
                +" again or say 'exit' to stop \n");
        }
        else if (whichResponseB == 1)
        {
            responseB = "Running back as fast as you could\n"
            +" you dont realize the huge pit of snakes at your feet.\n"
            +" You can jump over the pit and continue strait or turn back in fear\n"
            +" you cant jump that far. \n";
        }
        else if (whichResponseB == 2)
        {
            responseB = "You turn around scared of whats ahead.\n"
            +" when you get back you cna eithr go left or right or strait?\n"
            +" Which way do you cooose? \n";
        }
        else if (whichResponseB == 3)
        {
            responseB = "Turnng back you just run and run fast.\n"
            +" but you remebered what you had saw and heard a while back.\n"
            +" So you want to make a different call do you go left or strait? \n";
        }
        else if (whichResponseB == 4)
        {
            responseB = "Once you run back you see a mysterious man \n"
            +" crouched in the corner. \n"
            +"Do you try to pass him and go right or just go back again? \n";
        }
        else if (whichResponseB == 5)
        {
            responseB = "Congradulations! \n"
            +"Weather this was a long or short trip for you! \n"
            +"YOU MADE IT OUT! \n";
        }

        return responseB;
    }

}
