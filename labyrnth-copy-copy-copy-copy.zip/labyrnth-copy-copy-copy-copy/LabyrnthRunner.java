import java.util.Scanner;

public class LabyrnthRunner
{

	/**
	 * Create a Magpie, give it user input, and print its replies.
	 */
	public static void main(String[] args)
	{
		Labyrnth labyr = new Labyrnth();
		
		System.out.println (labyr.getGreeting());
		Scanner in = new Scanner (System.in);
		String statement = in.nextLine();
		
		while (!statement.equals("exit") && !statement.equals("get me out of here"))
		{
			System.out.println (labyr.getResponse(statement));
			statement = in.nextLine();
		}
	}

}
